// Sample catalog of popular books
var catalog = [
    { title: "Teach Like a Champion: 49 Techniques that Put Students on the Path to College", category: "Education" },
    { title: "The First Days of School: How to Be an Effective Teacher", category: "Education" },
    { title: "Mindset: The New Psychology of Success", category: "Education" },
    { title: "A People's History of the United States", category: "History" },
    { title: "Sapiens: A Brief History of Humankind", category: "History" },
    { title: "The Devil in the White City: Murder, Magic, and Madness at the Fair That Changed America", category: "History" },
    { title: "To Kill a Mockingbird", category: "Law" },
    { title: "The Art of War", category: "Law" },
    { title: "The Rule of Law", category: "Law" },
    { title: "Harry Potter and the Sorcerer's Stone", category: "Children" },
    { title: "The Very Hungry Caterpillar", category: "Children" },
    { title: "Goodnight Moon", category: "Children" },
    { title: "Rich Dad Poor Dad: What the Rich Teach Their Kids About Money That the Poor and Middle Class Do Not!", category: "Business" },
    { title: "The Lean Startup: How Today's Entrepreneurs Use Continuous Innovation to Create Radically Successful Businesses", category: "Business" },
    { title: "Thinking, Fast and Slow", category: "Business" }
];

// Function to search books by title
function searchBooks() {
    var searchInput = document.getElementById('searchInput').value.toLowerCase();
    var searchResults = catalog.filter(function(book) {
        return book.title.toLowerCase().includes(searchInput);
    });

    displaySearchResults(searchResults);
}

// Function to display search results
function displaySearchResults(results) {
    var searchResultsContainer = document.getElementById('searchResults');
    searchResultsContainer.innerHTML = '';

    if (results.length === 0) {
        searchResultsContainer.innerHTML = '<p>No results found.</p>';
    } else {
        results.forEach(function(book) {
            var resultItem = document.createElement('div');
            resultItem.innerHTML = '<h3>' + book.title + '</h3>' +
                                   '<p>Category: ' + book.category + '</p>';
            searchResultsContainer.appendChild(resultItem);
        });
    }
}
